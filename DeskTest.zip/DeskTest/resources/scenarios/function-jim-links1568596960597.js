(function(window, undefined) {

  var jimLinks = {
    "454b26e2-0d6f-45c6-8080-b0b00967975b" : {
      "Button_1" : [
        "d031fe78-5173-4b71-aba4-109a18bce135"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);